name='mglcmdtools'

from .mglcmdtools import rm_and_mkdir, runcmd, longStrings_not_match_shortStrings