name='mglcmdtools'

from .mglcmdtools import rm_and_mkdir, runcmd